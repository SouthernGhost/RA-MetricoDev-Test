There are 4 models:

random_forest_bin_classifier.pkl -> This model can be loaded using joblib.
	model = joblib.load('random_forest_bin_classifier.pkl')

ann_bin_classifier.pkl
	model = joblib.load('ann_bin_classifier.pkl')

bin_classifier.h5 -> This model is trained using tensorflow. It can be loaded using keras.
	keras.models.load_models('bin_classifier.h5')

bin_classifier.keras
	keras.models.load_models('bin_classifier.h5')